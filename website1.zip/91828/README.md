# iRepair Smart Devices Website

This is the official website for iRepair Smart Devices, a mobile phone repair service based in Orlando, FL.

## Project Structure

```
irepair-website/
├── index.html              # Main HTML file
├── assets/
│   ├── css/
│   │   └── styles.css      # All CSS styles
│   └── images/
│       └── hero-bg.jpg     # Hero section background image
```

## Deployment Instructions

1. **Download the Background Image**
   - Download the hero background image from: https://images.pexels.com/photos/699122/pexels-photo-699122.jpeg
   - Save it as `hero-bg.jpg` in the `assets/images/` directory

2. **Choose a Web Hosting Service**
   - Popular options include:
     - GitHub Pages (free)
     - Netlify (free tier available)
     - Vercel (free tier available)
     - Traditional web hosting (e.g., Bluehost, HostGator)

3. **Upload Files**
   - Upload the entire `irepair-website` directory to your web hosting service
   - Make sure to maintain the same directory structure

4. **Verify Deployment**
   - Visit your website URL to ensure everything is working correctly
   - Check that all images and styles are loading properly

## Local Testing

To test the website locally:
1. Open `index.html` in your web browser
2. Make sure the background image is in the correct location (`assets/images/hero-bg.jpg`)

## Maintenance

- Update the content in `index.html` as needed
- Modify styles in `assets/css/styles.css`
- Replace the background image in `assets/images/` if desired

## Contact

For any questions or support, contact:
- Email: irepairsmartdevicesorl@gmail.com
- Phone: (689) 500-1394 